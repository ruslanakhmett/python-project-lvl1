#!/usr/bin/env python
from brain_games import games, engine


def questions_main():
    engine.start(games.even)


if __name__ == '__main__':
    questions_main()
