#!/usr/bin/env python

def main():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()
