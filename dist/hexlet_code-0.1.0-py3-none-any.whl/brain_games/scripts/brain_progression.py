#!/usr/bin/env python
from brain_games import games, engine


def progression_main():
    engine.start(games.progression)


if __name__ == '__main__':
    progression_main()
