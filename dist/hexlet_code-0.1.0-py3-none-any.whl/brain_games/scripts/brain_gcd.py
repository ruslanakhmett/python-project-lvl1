#!/usr/bin/env python
from brain_games import games, engine


def gcd_main():
    engine.start(games.gcd)


if __name__ == '__main__':
    gcd_main()
