#!/usr/bin/env python
from brain_games import games, engine


def prime_main():
    engine.start(games.prime)


if __name__ == '__main__':
    prime_main()
