#!/usr/bin/env python
from brain_games import games, engine


def calc_main():
    engine.start(games.calc)


if __name__ == '__main__':
    calc_main()
